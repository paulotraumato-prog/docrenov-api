# App Médico

1. Faça upload no GitHub
2. Conecte ao Render
3. Configure variáveis de ambiente
4. Acesse /setup-db
5. Acesse /admin/upload-certificate